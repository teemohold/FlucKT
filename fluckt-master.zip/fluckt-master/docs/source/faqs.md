# FAQS

## 1、How to contribute to pyKT?
You can read [](index.rst#Development)
