## Installation
Since pyKT is a python-based library, you can specify to install it with the following command:

Create conda environment.

```
conda create --name=pykt python=3.7.5
source activate pykt
```


```
pip install -U pykt-toolkit
```
