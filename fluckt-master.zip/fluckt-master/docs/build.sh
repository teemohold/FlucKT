sphinx-apidoc -o ./source ../pykt/ -f
make clean
make html