#!/bin/bash
python all_start.py $1 start_sweep_$2_$3.sh $2 $3 $4 $5 $6 $7
